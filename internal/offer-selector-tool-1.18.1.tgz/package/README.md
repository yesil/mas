# offer-selector-tool
This is a React based UI that allows to discover [offer selectors](https://developers.corp.adobe.com/aos/docs/api/openapi/openapi.yml) and use them in different context.

e.g: insert the price, or select an offer selector to render its checkout URL.

Offer selectors are kind of saved search for AOS offers. They can return multiple offers.

Offer Selector Tool will assume an offer selector returns always a single offer, and always pick the first offer in the result.

## Local development
make sure you have `127.0.0.1	local.adobe.com` in your `/etc/hosts` file

Run `npm start` and follow the instructions in the console.

To see OST as in dialog add ?test=dialog parameter
[http://local.adobe.com:9008/?test=dialog](http://local.adobe.com:9008/?test=dialog)

To see OST as in  Milo add ?test=milo parameter
[http://local.adobe.com:9008/?test=milo](http://local.adobe.com:9008/?test=milo)

Before OST will start working you need to add AOS_ACCESS_TOKEN to your localStorage.
Generate a short-time living service token at https://imss.corp.adobe.com/#/client/stage/dexter-commerce-offers
This token lives 8h.
You can get an access token from your local or DEV AEM instance by hitting http://localhost:4502/conf/dexter/commerce/ims/token.json
Just make sure that 'aosApiKey' at /conf/global/sling:configs/com.adobe.dexter.commerce/ims is 'dexter-commerce-offers'
The token from the instance normally lasts 1 year.
```
localStorage.setItem('AOS_ACCESS_TOKEN', 'eyJhbGciOiJSUzI...')
```

## Local development - Milo
Steps to develop OST and see your changed updated in Milo locally:
1. In tacocat repo, in packages/offer-selector-tool run `npm run start-global`
2. It will open the webpack base path in your browser, add '/develop.js' to it (e.g. 'http://local.adobe.com:9007/develop.js')
3. Go to Milo repo, edit 'ost.js' to load your local OST: `await loadScript(`http://local.adobe.com:9007/develop.js`);`
4. in milo root run `hlx up`
5. Access [OST with parameters](http://localhost:3000/tools/ost?offerId=257E1D82082387D152029F93C1030624&type=checkoutUrl&text=buy-now&checkoutType=UCv3&workflowStep=email)

if you need to develop against production with other api keys (typically the ones from milo tools)
you can 'just' copy token as you usually do, and
add this to console:
```
localStorage.setItem('AOS_API_KEY', 'wcms-commerce-ims-user-prod');
localStorage.setItem('WCS_API_KEY', 'wcms-commerce-ims-ro-user-cc');
```

## If you get 'Oauth unauthorized...' error
In the last step, when you click on an Offer, OST will submit a POST request.
This post request to AOS will generate an OSI for the given offer.
Either you miss 'AOS_ACCESS_TOKEN' or it is expired or it doesn't match your API_KEY (e.g., dexter-commerce-offers).
```

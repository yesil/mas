#dev
just run
`npm run test` to get standalone Offer Selector Tool to test

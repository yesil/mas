import React, { useCallback, useMemo, useState, useEffect } from 'react';
import PropTypes from 'prop-types';

import {
    View,
    Flex,
    TabList,
    Tabs,
    Item,
    TabPanels,
} from '@adobe/react-spectrum';

import ProductsTab from './ProductsTab';
import OffersTab from './OffersTab';
import styles from './app.less';
import AppContext, { createAppContext } from './AppContext';
import debounce from 'lodash.debounce';
import { createLog } from '@dexter/tacocat-core';

const log = createLog('OfferSelectorTool');
const entitlementsKey = 'entitlements';
const offerKey = 'offer';

// using stage to make sure no external access is needed for this internal tool
// don't get confused by stage here, it's published products on prod we are looking at
const PRODUCTS_ENDPOINT =
    'https://www.stage.adobe.com/special/tacocat/products.js';

function OfferSelectorTool({
    appContext,
    onSelect,
    rootElement,
    containerGap,
}) {
    if (styles) {
        // hack to get app.less file bundled by swc.
    }

    const finalAppContext = useMemo(() => createAppContext(appContext), []);

    const [aosParams, setAosParams] = useState(finalAppContext.aosParams);
    const [globals, setGlobals] = useState(finalAppContext.globals);
    const [selectedProduct, setSelectedProduct] = useState();
    const [searchOfferId, setSearchOfferId] = useState(
        finalAppContext.searchOfferId
    );
    const [searchOfferSelectorId, setSearchOfferSelectorId] = useState(
        finalAppContext.searchOfferSelectorId
    );
    const [sendSearch, setSendSearch] = useState(finalAppContext.sendSearch);
    const [searchText, setSearchText] = useState(
        finalAppContext.searchOfferId ??
            finalAppContext.searchOfferSelectorId ??
            ''
    );
    const [selectedTabKey, setSelectedTabKey] = useState(entitlementsKey);
    const [allProducts, setProducts] = useState(finalAppContext.allProducts);
    const [filteredProducts, setFilteredProducts] = useState([]);
    const [actualContainerHeight, setActualContainerHeight] = useState(
        rootElement.offsetHeight
    );

    const updateContainerHeight = useMemo(
        () =>
            debounce(() => {
                setActualContainerHeight(
                    rootElement.offsetHeight - containerGap
                );
            }, 250),
        []
    );

    useEffect(() => {
        window.addEventListener('resize', updateContainerHeight);
        updateContainerHeight();
        return () =>
            window.removeEventListener('resize', updateContainerHeight);
    }, [updateContainerHeight]);

    useEffect(
        () =>
            new Promise((resolve, reject) => {
                if (window?.tacocat?.products) {
                    resolve(Object.entries(window.tacocat.products));
                    return;
                }
                let script = document.querySelector(
                    `head > script[src="${PRODUCTS_ENDPOINT}"]`
                );
                if (!script) {
                    const { head } = document;
                    script = document.createElement('script');
                    script.setAttribute('src', PRODUCTS_ENDPOINT);
                    script.setAttribute('type', 'text/javascript');
                    head.append(script);
                }

                const onScript = (event) => {
                    script.removeEventListener('load', onScript);
                    script.removeEventListener('error', onScript);

                    if (event.type === 'error') {
                        reject(
                            new Error(`error loading script: ${script.src}`)
                        );
                    } else if (event.type === 'load') {
                        resolve(Object.entries(window.tacocat.products));
                    }
                };
                script.addEventListener('load', onScript);
                script.addEventListener('error', (event) => {
                    reject(new Error(`error loading script: ${script.src}`));
                });
            }).then(setProducts),
        [setProducts]
    );
    useEffect(() => {
        // when search text changes, uncheck the selected product
        setAosParams({
            ...aosParams,
            arrangementCode: '',
        });
    }, [searchText]);

    useEffect(() => {
        if (!aosParams.arrangementCode) {
            setSelectedProduct();
            return;
        }
        const foundProduct = filteredProducts.find(({ code }) => {
            return code === aosParams.arrangementCode;
        });
        if (!foundProduct) {
            log.warn('No product found with code', aosParams.arrangementCode);
            setSelectedProduct();
            return;
        }
        if (selectedProduct?.code !== foundProduct.code) {
            setSelectedProduct(foundProduct);
        }
    }, [aosParams, selectedProduct, filteredProducts]);

    const goToStep = (step) => {
        if (step === entitlementsKey) {
            setSelectedProduct();
            setAosParams({
                ...aosParams,
                pricePoint: '',
            });
        }
        setSelectedTabKey(step);
    };

    const onTabChange = useCallback(
        (step) => {
            if (!selectedProduct && step === offerKey) {
                return;
            }
            goToStep(step);
        },
        [selectedProduct]
    );

    const productsTab = useMemo(
        () =>
            filteredProducts ? (
                <ProductsTab nextStep={() => goToStep(offerKey)}></ProductsTab>
            ) : null,
        [selectedProduct, aosParams, filteredProducts]
    );

    const offersTab = useMemo(() => {
        if (selectedProduct === undefined) {
            return <View />;
        } else
            return (
                <OffersTab
                    previousStep={() => goToStep(entitlementsKey)}
                    onSelect={onSelect}
                    ctaTextOption={appContext.ctaTextOption}
                ></OffersTab>
            );
    }, [selectedProduct, aosParams]);

    // main tab container
    return (
        <AppContext.Provider
            value={{
                ...finalAppContext,
                allProducts,
                filteredProducts,
                setFilteredProducts,
                aosParams,
                setAosParams,
                selectedProduct,
                searchOfferId,
                setSearchOfferId,
                searchOfferSelectorId,
                setSearchOfferSelectorId,
                searchText,
                setSearchText,
                sendSearch,
                setSendSearch,
                globals,
                setGlobals,
                containerHeight: actualContainerHeight,
            }}
        >
            <View height="100%">
                <Tabs
                    aria-label="Offer Selector Tool"
                    height="100%"
                    onSelectionChange={onTabChange}
                    selectedKey={selectedTabKey}
                >
                    <Flex justifyContent="center">
                        <View paddingTop="static-size-125">
                            <TabList>
                                <Item key={entitlementsKey}>
                                    Select your product and entitlements
                                </Item>
                                <Item key={offerKey}>Select your offer</Item>
                            </TabList>
                        </View>
                    </Flex>
                    <View backgroundColor="gray-100" height="100%">
                        <TabPanels height="100%">
                            <Item key={entitlementsKey}>{productsTab}</Item>
                            <Item key={offerKey}>{offersTab}</Item>
                        </TabPanels>
                    </View>
                </Tabs>
            </View>
        </AppContext.Provider>
    );
}

OfferSelectorTool.propTypes = {
    appContext: PropTypes.any.isRequired,
    onSelect: PropTypes.func.isRequired,
    rootElement: PropTypes.any.isRequired,
    containerGap: PropTypes.number,
};

OfferSelectorTool.defaultProps = {
    appContext: {},
    onSelect: () => {},
    containerGap: 0,
};

export default OfferSelectorTool;

function computePlanType({ commitment, term }) {
    if (commitment === 'YEAR') {
        if (term === 'MONTHLY') {
            return 'ABM';
        } else if (term === 'ANNUAL') {
            return 'PUF';
        }
    } else if (commitment === 'MONTH') {
        if (term === 'MONTHLY') {
            return 'M2M';
        }
    } else if (commitment === 'PERPETUAL') {
        return 'PERPETUAL';
    } else if (commitment === 'TERM_LICENSE' && term === 'P3Y') {
        return 'P3Y';
    }
    return undefined;
}

export { computePlanType };

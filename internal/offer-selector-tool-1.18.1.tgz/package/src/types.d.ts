import {
    Environment,
    Landscape,
    ProviderEnvironment,
} from '@pandora/data-source-utils';
import {
    MarketSegment,
    CustomerSegment,
    OfferType,
    Offer,
} from '@pandora/data-models-odm';
import { PlaceholderEngine } from '@dexter/tacocat-core/types';

/**
 * Unmounts the Offer Selector Tool react application.
 * When invoked directly, the onClose callback will not be called.
 */
export declare function closeDialog(): void;

/**
 * List of all the AOS search paramters.
 */
export declare type AosParams = {
    arrangementCode: string;
    offerType: string;
    pricePoint: string;
    commitment: string;
    term: string;
    customerSegment: string;
    marketSegment: string;
};

/**
 * Plan types selectable in Offer Selector Tool
 */
export declare enum PlanType {
    PUF,
    M2M,
    ABM,
    PERPETUAL,
    P3Y,
}

/**
 * A product displayed in Offer Selector Tool
 */
export declare type Product = {
    id?: string;
    arrangement_code: string;
    name: string;
    /**
     * url of the icon.
     */
    icon: string;
    planTypes: { [key in PlanType]?: boolean };
    customerSegments: { [key in CustomerSegment]?: boolean };
    offerTypes: { [key in OfferType]?: boolean };
    marketSegments: { [key in MarketSegment]?: boolean };
};

/**
 * List of products displayed in Offer Selector Tool
 */
export declare type Products = {
    [key: string]: Product;
};

export declare type PlaceholderTypeMetadata = {
    type: string;
    name: string;
    description?: string;
    doc?: string;
};

export declare type PlaceholderOptions = {
    displayFormatted: boolean;
    displayRecurrence: boolean;
    displayPerUnit: boolean;
    displayTax: boolean;
    forceTaxExclusive: boolean;
    displayOldPrice: boolean;
};
/**
 * Not AOS related
 */
export declare type ContextParams = {
    aosConfig: AosConfig;
    aosParams: AosParams;
    checkoutWorkflow: string;
    checkoutWorkflowStep: string;
    checkoutClientId: string;
    clientId: string;
    country: string;
    disableOfferSelection: boolean;
    disablePlaceholderSelection: boolean;
    engine: PlaceholderEngine;
    onCancel: () => void;
    baseUrl: string;
    env: ProviderEnvironment;
    environment: Environment;
    globals: any;
    landscape: Landscape;
    placeholderTypes: PlaceholderTypeMetadata[];
    products: Products;
    searchArrangementCode: string;
    defaultPlaceholderOptions: PlaceholderOptions;
    offerSelectorPlaceholderOptions: PlaceholderOptions;
    zIndex: number;
    searchText: string;
    searchOfferId: string;
    searchOfferSelectorId: string;
    sendSearch: boolean;
    searchParameters: any;
    containerHeight: number;
    setAosParams: (aosParams: AosParams) => void;
    setSearchText: (text: string) => void;
    setSendSearch: (sendSearch: boolean) => void;
    setSearchOfferId: (offerId: string) => void;
    setSearchOfferSelectorId: (offerSelectorId: string) => void;
    filteredProducts: Product[];
    setFilteredProducts: (products: Product[]) => void;
};

export type createAppContext = (
    params: Partial<ContextParams>
) => ContextParams;

/**
 *
 * Callback invoked when the modal is closed. All the current options, offer selector Id and type (e.g: price, date, checkoutUrl, etc...) are passed as parameters of the callabck.
 * @param offerSelectorId
 * @param type
 * @param offer
 * @param options name of the options that are selected
 */
export declare function OnSelect(
    offerSelectorId: string | undefined,
    type: string | undefined,
    offer: Offer | undefined,
    options: string[],
    promoOverride: string | undefined
): void;

/**
 * @param rootElement DOM element in which to render the Offer Selector Tool dialog.
 * @param onSelect
 * @param context
 */
export declare function openAsDialog(
    rootElement: Element,
    onSelect: OnSelect,
    context: Partial<ContextParams>
): closeDialog;

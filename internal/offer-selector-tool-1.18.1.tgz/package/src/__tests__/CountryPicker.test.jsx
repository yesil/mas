import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import CountryPicker from '../CountryPicker';
import { defaultTheme, Provider } from '@adobe/react-spectrum';

describe('CountryPicker', () => {
    it('should fetch and display country list', async () => {
        const countryList = [
            { 'iso2-code': 'AE' },
            { 'iso2-code': 'GB' },
            { 'iso2-code': 'US' },
        ];
        // Mock the fetch API to return a fake country list
        global.fetch = jest.fn().mockResolvedValue({
            json: jest.fn().mockResolvedValue(countryList),
        });
        const setGlobalsMock = jest.fn();
        // Render the component with mock props
        const { queryByText, getAllByText } = render(
            <Provider theme={defaultTheme}>
                <CountryPicker
                    country="US"
                    globals={{}}
                    setGlobals={setGlobalsMock}
                />
            </Provider>
        );
        // Wait for the country list to be loaded and displayed
        const selector = getAllByText(/Choose Country*/i);
        expect(selector[0]).toBeInTheDocument();
        await waitFor(() => getAllByText('US'));

        expect(getAllByText('US')[0]).toBeInTheDocument();
        expect(getAllByText('AE')[0]).toBeInTheDocument();
        expect(queryByText('DE')).not.toBeInTheDocument();
    });
});

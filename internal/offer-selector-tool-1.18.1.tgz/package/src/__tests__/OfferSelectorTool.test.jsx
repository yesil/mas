/* eslint-disable react/prop-types */
import React from 'react';
import { EnvProvider } from '@pandora/react-env-provider';
import { FetchProvider } from '@pandora/react-fetch-provider';
import { AuthProvider } from '@pandora/react-auth-provider';

import { defaultTheme, Provider } from '@adobe/react-spectrum';

import { render, act, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import { Environment } from '@pandora/data-source-utils';
import OfferSelectorTool from '../OfferSelectorTool';

const appContext = (overrides = {}) => ({
    apiKey: 'dexter-commerce-offers',
    updateSearchParams: jest.fn(),
    engine: undefined,
    globals: [
        {
            checkoutWorkflow: 'UCv3',
            country: 'US',
            language: 'en',
        },
    ],
    defaultPlaceholderOptions: {},
    offerSelectorPlaceholderOptions: {},
    placeholderTypes: [],
    ...overrides,
    allProducts: [],
});

const TestOfferSelectorTool = ({ overrides, onSelect, fetch }) => {
    window.tacocat = {
        products: {
            ccsn_direct_individual: {
                name: 'CC All Apps Test',
                arrangement_code: 'ccsn_direct_individual',
                icon: '',
                planTypes: {
                    PUF: true,
                    ABM: true,
                },
                customerSegments: {
                    INDIVIDUAL: true,
                },
                marketSegments: {
                    COM: true,
                },
            },
        },
    };

    const context = appContext({
        ...overrides,
        allProducts: Object.entries(window.tacocat.products),
    });

    return (
        <Provider theme={defaultTheme}>
            <EnvProvider value={Environment.PRODUCTION}>
                <AuthProvider
                    value={{
                        getAccessToken: () => {
                            return 'test';
                        },
                    }}
                >
                    <FetchProvider value={fetch}>
                        <OfferSelectorTool
                            appContext={context}
                            onSelect={onSelect}
                            rootElement={document.body}
                        ></OfferSelectorTool>
                    </FetchProvider>
                </AuthProvider>
            </EnvProvider>
        </Provider>
    );
};

describe('Products tab', () => {
    const jsonResponse = jest.fn();
    const textResponse = jest.fn();
    const onSelect = jest.fn();
    const onCancel = jest.fn();

    const fetchMock =
        (success = true) =>
        () =>
            Promise.resolve({
                ok: success,
                json: () => Promise.resolve(jsonResponse()),
                text: () => Promise.resolve(textResponse()),
            });

    beforeEach(() => {
        jsonResponse.mockReset();
        textResponse.mockReset();
        onSelect.mockReset();
        onCancel.mockReset();
    });

    test('cancel button', async () => {
        const { getByTestId } = render(
            <TestOfferSelectorTool
                overrides={{ onCancel }}
                fetch={fetchMock(true)}
                onSelect={onSelect}
            />
        );
        const cancelButton = getByTestId('productsTab/cancelButton');
        await act(async () => {
            userEvent.click(cancelButton);
        });
        expect(onCancel).toHaveBeenCalledOnce();
    });

    test('search by valid offer ID', async () => {
        jsonResponse.mockReturnValueOnce([
            {
                offer_type: 'BASE',
                price_point: 'REGULAR',
                commitment: 'MONTH',
                term: 'MONTHLY',
                product_code: 'CCSN',
                product_arrangement_code: 'ccsn_direct_individual',
                customer_segment: 'INDIVIDUAL',
                market_segments: ['COM'],
                sales_channel: 'DIRECT',
                language: 'MULT',
            },
        ]);
        const { getByTestId } = render(
            <TestOfferSelectorTool
                fetch={fetchMock(true)}
                onSelect={onSelect}
            />
        );
        const searchField = getByTestId('productsTab/search');
        expect(searchField).toBeVisible();
        await act(async () => {
            //       .type is slower and makes the test fail
            userEvent.paste(searchField, '257E1D82082387D152029F93C1030624');
        });
        await waitFor(() => expect(jsonResponse).toHaveBeenCalledTimes(1));
        await act(async () => {
            userEvent.type(searchField, '{enter}');
        });
        const offersTabResult = getByTestId('offersTab/result');
        expect(offersTabResult).toBeVisible();
    });

    test('search by offer selector id', async () => {
        jsonResponse.mockReturnValueOnce({
            id: 'mle9grW2W9hcWBrxyvgh3GVpvPelNCTU7SgVFhmKXYg',
            product_arrangement_code: 'ccsn_direct_individual',
            commitment: 'YEAR',
            term: 'ANNUAL',
            customer_segment: 'INDIVIDUAL',
            market_segment: 'COM',
            offer_type: 'BASE',
        });

        const { getByTestId } = render(
            <TestOfferSelectorTool
                fetch={fetchMock(true)}
                onSelect={onSelect}
            />
        );
        const searchField = getByTestId('productsTab/search');

        await act(async () => {
            //       .type is slower and makes the test fail
            userEvent.paste(
                searchField,
                'mle9grW2W9hcWBrxyvgh3GVpvPelNCTU7SgVFhmKXYg'
            );
        });
        await waitFor(() => {
            expect(jsonResponse).toHaveBeenCalledTimes(1);
        });
        await act(async () => {
            userEvent.type(searchField, '{enter}');
        });
        const offersTabResult = getByTestId('offersTab/result');
        expect(offersTabResult).toBeVisible();
    });

    test('search by invalid offer ID', async () => {
        textResponse.mockReturnValueOnce('generic error');
        const { getByTestId } = render(
            <TestOfferSelectorTool
                fetch={fetchMock(false)}
                onSelect={onSelect}
            />
        );
        const searchField = getByTestId('productsTab/search');
        expect(searchField).toBeVisible();
        await act(async () => {
            userEvent.paste(searchField, '257E1D82082387D152029F93C1030624');
        });
        expect(jsonResponse).toHaveBeenCalledTimes(0);
        await act(async () => {
            userEvent.type(searchField, '{enter}');
        });
        expect(searchField).toBeVisible();
        expect(textResponse).toHaveBeenCalledTimes(1);
    });
});

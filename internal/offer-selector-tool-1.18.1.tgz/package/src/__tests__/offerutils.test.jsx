import { Landscape } from '@pandora/data-source-utils';
import { offerFilter, OFFER_ID_PATTERN } from '../offerutils';

const offerId = '55DFFCFBA3A555D01E117D901C82F5B4';

describe('test offer utils', () => {
    test('offerid detection pattern', async () => {
        expect(OFFER_ID_PATTERN.test('123')).toBeFalse();
        expect(OFFER_ID_PATTERN.test(offerId)).toBeTrue();
        expect(OFFER_ID_PATTERN.test(' foo ' + offerId)).toBeFalse();
        expect(
            OFFER_ID_PATTERN.test('123456789012345678901234567890ZZ')
        ).toBeFalse();
    });

    test('filters out right set of offers', async () => {
        const products = [
            {
                customerSegments: { INDIVIDUAL: true, TEAM: true },
                marketSegments: { COM: true },
                draft: true,
                arrangement_code: 'P_1',
                name: 'P1',
            },
            {
                customerSegments: { INDIVIDUAL: true, TEAM: true },
                marketSegments: { COM: true },
                arrangement_code: 'P_2',
                name: 'P2',
            },
            {
                customerSegments: { INDIVIDUAL: true, TEAM: true },
                marketSegments: { COM: true },
                draft: true,
                arrangement_code: 'P_3',
                name: 'P3',
            },
            {
                customerSegments: { INDIVIDUAL: true, TEAM: true },
                marketSegments: { EDU: true },
                arrangement_code: 'P_4',
                name: 'P4',
            },
            {
                customerSegments: { INDIVIDUAL: true, TEAM: true },
                marketSegments: { EDU: true },
                draft: true,
                arrangement_code: 'P_5',
                name: 'P5',
            },
            {
                customerSegments: { INDIVIDUAL: true, TEAM: true },
                marketSegments: { EDU: true },
                arrangement_code: 'P_6',
                name: 'P6',
            },
        ];
        expect(
            products
                .filter((p) =>
                    offerFilter(
                        /.*/,
                        Landscape.DRAFT,
                        {
                            marketSegment: 'COM',
                            customerSegment: 'INDIVIDUAL',
                        },
                        p
                    )
                )
                .map((p) => p.name)
        ).toEqual(['P1', 'P2', 'P3']);
        expect(
            products
                .filter((p) =>
                    offerFilter(
                        /.*/,
                        Landscape.PUBLISHED,
                        {
                            marketSegment: 'COM',
                            customerSegment: 'INDIVIDUAL',
                        },
                        p
                    )
                )
                .map((p) => p.name)
        ).toEqual(['P2']);
        expect(
            products
                .filter((p) =>
                    offerFilter(
                        /P_3/,
                        Landscape.DRAFT,
                        {
                            marketSegment: 'COM',
                            customerSegment: 'INDIVIDUAL',
                        },
                        p
                    )
                )
                .map((p) => p.name)
        ).toEqual(['P3']);
    });

    // dumy test
    test.skip('test for debugging purpose', async () => {
        expect(
            offerFilter(
                null,
                undefined,
                {
                    arrangementCode:
                        'creative_cloud_all_apps_with_1tb_individual',
                    commitment: 'YEAR',
                    customerSegment: 'INDIVIDUAL',
                    marketSegment: 'COM',
                    offerSelectorId:
                        'mle9grW2W9hcWBrxyvgh3GVpvPelNCTU7SgVFhmKXYg',
                    offerType: 'BASE',
                    pricePoint: 'INDIV_CCES_COM_1TB',
                    term: 'ANNUAL',
                },
                {
                    name: 'CC All Apps Test',
                    arrangement_code: 'ccle_direct_indirect_team',
                    icon: '',
                    planTypes: {
                        PUF: true,
                        ABM: true,
                    },
                    customerSegments: {
                        INDIVIDUAL: true,
                    },
                    marketSegments: {
                        COM: true,
                    },
                }
            )
        ).toBeTrue();
    });
});

import React from 'react';
import {
    Environment,
    Landscape,
    ProviderEnvironment,
} from '@pandora/data-source-utils';

/**
  @type { import('./types').AosConfig }
 */
const defaultAosConfig = {
    apiKey: '',
    landscape: Landscape.DRAFT,
};

/**
 @type { import('./types').AosParams }
 */
const defaultAosParams = {
    commitment: '',
    term: '',
    customerSegment: 'INDIVIDUAL',
    offerType: 'BASE',
    marketSegment: 'COM',
};

const DEFAULT_PLACEHOLDER_TYPES = [
    {
        type: 'price',
        name: 'Price',
        description: 'Formatted price, can be inlined with neighbour text',
        doc: '#',
    },
    {
        type: 'priceOptical',
        name: 'Optical price',
        description:
            'Formatted price calculating monthly payments for annual plans, can be inlined with neighbour text',
        doc: '#',
    },
    {
        type: 'priceAnnual',
        name: 'Annual price',
        description:
            'Formatted price calculating annual payments for ABM plan, can be inlined with neighbour text',
        doc: '#',
    },
    {
        type: 'priceStrikethrough',
        name: 'Strikethrough price',
        description:
            'Formatted price displayed as strikethrough, can be inlined with neighbour text',
        doc: '#',
    },
    {
        type: 'checkoutUrl',
        name: 'Checkout URL',
        description: 'Checkout URl for a selected offer',
        doc: '#',
    },
];

/**
 @type { import('./types').ContextParams }
 */
const defaultAppValues = {
    baseUrl: String,
    env: ProviderEnvironment.PRODUCTION,
    environment: Environment.PRODUCTION,
    defaultPlaceholderOptions: {
        displayFormatted: true,
        displayRecurrence: true,
        displayPerUnit: false,
        displayTax: false,
        forceTaxExclusive: false,
        displayOldPrice: true,
    },
    disableOfferSelection: false,
    disablePlaceholderSelection: false,
    aosParams: defaultAosParams,
    aosConfig: defaultAosConfig,
    zIndex: 20000,
    searchText: '',
    searchOfferId: undefined,
    searchOfferSelectorId: undefined,
};

/**
 * @type { import('./types').createAppContext }
 */
function createAppContext({
    accessToken,
    allProducts,
    apiKey,
    aosParams = {},
    checkoutClientId,
    onCancel,
    baseUrl,
    env,
    environment,
    landscape,
    defaultPlaceholderOptions = defaultAppValues.defaultPlaceholderOptions,
    offerSelectorPlaceholderOptions = defaultAppValues.defaultPlaceholderOptions,
    disableOfferSelection = false,
    disablePlaceholderSelection = false,
    engine,
    globals = [],
    placeholderTypes = DEFAULT_PLACEHOLDER_TYPES,
    zIndex = defaultAppValues.zIndex,
    promotionCode,
    storedPromoOverride,
    searchOfferId,
    searchOfferSelectorId,
    searchParameters = new URLSearchParams(),
    containerHeight = 1024,
}) {
    return {
        ...defaultAppValues,
        accessToken,
        aosParams: Object.assign({ ...defaultAosParams }, aosParams),
        allProducts,
        apiKey,
        checkoutClientId,
        onCancel,
        baseUrl,
        env,
        environment,
        landscape,
        defaultPlaceholderOptions: {
            ...defaultAppValues.defaultPlaceholderOptions,
            ...defaultPlaceholderOptions,
        },
        offerSelectorPlaceholderOptions: {
            ...defaultAppValues.defaultPlaceholderOptions,
            ...defaultPlaceholderOptions,
            ...offerSelectorPlaceholderOptions,
        },
        disableOfferSelection,
        disablePlaceholderSelection,
        promotionCode,
        storedPromoOverride,
        engine,
        globals,
        placeholderTypes,
        zIndex,
        searchOfferId: disableOfferSelection ? undefined : searchOfferId,
        searchOfferSelectorId: disableOfferSelection
            ? undefined
            : searchOfferSelectorId,
        sendSearch: !!(searchOfferId || searchOfferSelectorId),
        searchParameters,
        containerHeight,
    };
}

const AppContext = React.createContext(defaultAppValues);

export default AppContext;
export { createAppContext };

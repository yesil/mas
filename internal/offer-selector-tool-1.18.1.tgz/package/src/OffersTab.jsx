import {
    Button,
    Checkbox,
    CheckboxGroup,
    Flex,
    Grid,
    Text,
    TabList,
    Tabs,
    Item,
    TabPanels,
    ToggleButton,
    View,
} from '@adobe/react-spectrum';
import React, {
    useCallback,
    useContext,
    useEffect,
    useMemo,
    useState,
} from 'react';
import PropTypes from 'prop-types';

import ChevronDoubleLeft from '@spectrum-icons/workflow/ChevronDoubleLeft';
import ChevronDoubleRight from '@spectrum-icons/workflow/ChevronDoubleRight';

import { useOfferSearch, useOfferSelector } from '@pandora/data-source-offers';
import { AosClient, ServiceProvider } from '@pandora/data-source-aos';
import {
    BuyingProgram,
    Commitment,
    SalesChannel,
} from '@pandora/data-models-odm';

import { PlaceholderContext } from '@dexter/tacocat-react-placeholders';

import resolveOfferSelector from './resolveOfferSelector';

import Offer from './Offer';
import AppContext from './AppContext';
import { PrevNext } from './PropTypes';

import PlaceholderKey from './PlaceholderKey';
import { createLog, PlanType, applyPlanType } from '@dexter/tacocat-core';
import { computePromoStatus } from '@dexter/tacocat-core';
import CheckoutTab from './CheckoutTab';
import { getSelectedCheckoutType, getSelectedWorkflowStep } from './checkout';

import { PromoTag } from './PromoTag';

const log = createLog('OfferSelectorTool');

const defaultAosParams = {
    buyingProgram: BuyingProgram.RETAIL,
    merchant: 'ADOBE',
    salesChannel: SalesChannel.DIRECT,
    serviceProviders: [ServiceProvider.PRICING],
};

const KEY_PRICE = 'price';
function OffersTab({ previousStep, onSelect, ctaTextOption }) {
    const {
        aosParams,
        searchOfferId,
        selectedProduct,
        accessToken,
        apiKey,
        defaultPlaceholderOptions,
        offerSelectorPlaceholderOptions,
        disableOfferSelection,
        disablePlaceholderSelection,
        globals,
        baseUrl,
        env,
        environment,
        landscape,
        promotionCode,
        storedPromoOverride,
        engine,
        placeholderTypes,
        onCancel,
        checkoutClientId,
        searchParameters,
        containerHeight,
        filteredProducts,
    } = useContext(AppContext);

    const country = globals[0]?.country;
    const queryOptions = {
        apiKey,
        environment,
        landscape,
        pageSize: 1000,
    };

    const [offers, setOffers] = useState([]);

    const [expandDetails, setExpandDetails] = useState(true);

    // checkout parameteres
    const [checkoutType, setCheckoutType] = useState(
        getSelectedCheckoutType(searchParameters)
    );
    const [workflowStep, setWorkflowStep] = useState(
        getSelectedWorkflowStep(searchParameters, checkoutType)
    );

    const [ctaText, setCtaText] = useState(
        ctaTextOption?.getSelectedText(searchParameters)
    );
    // placeholder type
    const selectedPlaceholderType = searchParameters.get('type');
    const selectedTab =
        !!selectedPlaceholderType &&
        selectedPlaceholderType.startsWith('checkout')
            ? 'checkout'
            : 'price';

    // initialize the placeholder option checkboxes
    // note that https://jira.corp.adobe.com/browse/MWPW-134663
    // need to invert logic for checkbock "Disable - Include Tax"
    // corresponds to forceTaxExclusive price
    const [placeholderOptions, setPlaceholderOptions] = useState([]);
    useEffect(() => {
        setPlaceholderOptions(
            Object.entries({
                ...defaultPlaceholderOptions,
                ...offerSelectorPlaceholderOptions,
            })
                .filter(([, value]) => !value)
                .map(([key]) => key)
        );
    }, []);

    //initialize the promotion context status
    const [promoOverride, setPromoOverride] = useState(storedPromoOverride);
    const [promoStatus, setPromoStatus] = useState(
        computePromoStatus(promoOverride, promotionCode)
    );
    useEffect(() => {
        setPromoStatus(computePromoStatus(promoOverride, promotionCode));
    }, [promoOverride]);

    const [selectedOfferSelectorReady, setSelectedOfferSelectorReady] =
        useState(false);
    const [offerSelectorId, setOfferSelectorId] = useState();
    const [selectedOffer, setSelectedOffer] = useState();

    // this is invoked when the use button is clicked on a placeholder
    const onSelectWithAosParams = (osi, type, placeholderOptions) => {
        if (!selectedOffer) return;
        onSelect(
            osi,
            type,
            selectedOffer,
            placeholderOptions,
            promoStatus.isOverriden ? promoStatus.overridenPromoCode : undefined
        );
    };

    const {
        arrangementCode,
        pricePoint,
        commitment,
        term,
        offerType,
        customerSegment,
        marketSegment,
    } = aosParams;

    const { planType } = applyPlanType({ commitment, term });
    // tab 2 / result text
    const resultText = useMemo(() => {
        if (!aosParams) return null;
        return ` ${selectedProduct.name}, ${
            planType ? planType + ',' : ''
        } ${customerSegment}, ${offerType}, ${marketSegment}`;
    }, [aosParams, planType, offerType, customerSegment, marketSegment]);

    const search = useOfferSearch((fetchOptions) => {
        return new AosClient({
            ...fetchOptions,
            landscape,
            env,
            baseUrl,
        });
    });

    useEffect(() => {
        const language =
            country === 'GB' || commitment === Commitment.PERPETUAL
                ? 'EN'
                : 'MULT';
        search(
            {
                ...defaultAosParams,
                arrangementCode: [arrangementCode],
                pricePoint: [pricePoint],
                commitment,
                term,
                offerType,
                customerSegment,
                marketSegment,
                country,
                language,
            },
            queryOptions
        )
            .then((res) => res.data)
            .then((offers) => offers.map(applyPlanType))
            .then((offers) =>
                offers.map((offer) => {
                    offer.id = offer.offer_id;
                    offer.name = selectedProduct.name;
                    offer.icon = selectedProduct.icon;
                    return offer;
                })
            )
            .then((offers) =>
                offers.sort(
                    (
                        { name: nameLeft, price_point: pricePointLeft },
                        { name: nameRight, price_point: pricePointRight }
                    ) => {
                        return `${nameRight}${pricePointRight}`.localeCompare(
                            `${nameLeft}${pricePointLeft}`
                        );
                    }
                )
            )
            .then(setOffers)
            .catch((error) => log.error(error.message));
    }, [filteredProducts]);

    const [createOfferSelector] = useOfferSelector((fetchOptions) => {
        const finalFetchOptions = {
            ...fetchOptions,
            accessToken,
            landscape,
            apiKey,
            env,
            baseUrl,
        };
        return new AosClient(finalFetchOptions);
    });

    // if offers contain a single offer, select it
    useEffect(() => {
        if (offers.length === 1) {
            setSelectedOffer(offers[0]);
        }
    }, [offers]);

    // create offer selector for the current search
    useEffect(() => {
        if (offers.length === 0) return;
        const [{ buying_program, merchant, sales_channel }] = offers;
        const {
            arrangementCode: product_arrangement_code,
            commitment,
            customerSegment: customer_segment,
            marketSegment: market_segment,
            offerType: offer_type,
            term,
        } = aosParams;

        const offerSelectorParams = {
            buying_program,
            merchant,
            sales_channel,
            product_arrangement_code,
            customer_segment,
            market_segments: [market_segment],
            offer_type,
        };
        if (commitment && term) {
            Object.assign(offerSelectorParams, {
                commitment,
                term,
            });
        }
        if (disableOfferSelection) {
            resolveOfferSelector(
                offerSelectorParams,
                createOfferSelector,
                queryOptions
            ).then(setOfferSelectorId);
        }
    }, [offers, disableOfferSelection, createOfferSelector]);

    // create offer selector for current offer
    useEffect(() => {
        if (!selectedOffer) return;

        resolveOfferSelector(selectedOffer, createOfferSelector, queryOptions)
            .then((value) => {
                setOfferSelectorId(value);
                setSelectedOfferSelectorReady(true);
            })
            .catch((error) => log.error(error.message));
    }, [selectedOffer, createOfferSelector, promoOverride]);

    useEffect(() => {
        if (!searchOfferId) return;
        const offer = offers.find(({ offer_id }) => offer_id === searchOfferId);
        if (offer) {
            setSelectedOffer(offer);
        }
    }, [offers]);

    const [pricePlaceholders, checkoutPlaceholders] = useMemo(() => {
        const getPlaceholders = (predicate) => {
            if (!(selectedOfferSelectorReady && offerSelectorId && engine))
                return <div></div>;
            const placeholders = placeholderTypes
                .filter(predicate)
                .filter(({ type }) => {
                    if (type === 'priceAnnual' && selectedOffer.planType !== PlanType.ABM) return false;
                    if (type === 'priceOptical' && selectedOffer.planType !== PlanType.PUF) return false;
                    return true;
                })
                .map(({ type, name, description, doc }) => {
                    const key = `${offerSelectorId}.${type}`;
                    const isPerpetual = selectedOffer.commitment === Commitment.PERPETUAL;
                    return (
                        <PlaceholderKey
                            key={key}
                            offerSelectorId={offerSelectorId}
                            type={type}
                            name={name}
                            description={description}
                            doc={doc}
                            onSelect={onSelectWithAosParams}
                            options={placeholderOptions}
                            workflowStep={workflowStep}
                            marketSegment={marketSegment}
                            promotionCode={promoStatus.effectivePromoCode}
                            clientId={checkoutClientId}
                            checkoutType={checkoutType}
                            isPerpetual={isPerpetual}
                            ctaText={ctaText}
                        />
                    );
                });

            return (
                <PlaceholderContext.Provider value={{ engine, globals }}>
                    <Grid
                        columns={['1fr', 'size-1000']}
                        autoRows={['size-400', 'auto', 'size-400', 'size-400']}
                    >
                        {placeholders}
                    </Grid>
                </PlaceholderContext.Provider>
            );
        };
        return [
            getPlaceholders(({ type }) => !type.includes('checkout')),
            getPlaceholders(({ type }) => type.includes('checkout')),
        ];
    }, [
        selectedOfferSelectorReady,
        offerSelectorId,
        engine,
        globals,
        placeholderOptions,
        onSelectWithAosParams,
    ]);

    const [currentPlaceholderTab, setCurrentPlaceholderTab] =
        useState(KEY_PRICE);

    const offerSelectHandler = useCallback((offer) => {
        if (disableOfferSelection) return;
        setSelectedOffer(offer);
    }, []);

    const useClickHandler = useCallback(() => {
        onSelect(
            offerSelectorId,
            null,
            selectedOffer,
            null,
            promoStatus.isOverriden ? promoStatus.effectivePromoCode : null
        );
    }, [selectedOffer, offerSelectorId]);

    const offerListView = useMemo(() => {
        if (offers.length === 0) return null;
        const offersView = offers.map((offer) => (
            <div key={offer.offer_id} onClick={() => offerSelectHandler(offer)}>
                <Offer
                    selected={offer === selectedOffer}
                    offer={{
                        ...offer,
                        ...selectedProduct,
                    }}
                />
            </div>
        ));
        return (
            <Flex
                direction="column"
                gap="size-300"
                aria-label="Offers"
                alignSelf="stretch"
                justifySelf="stretch"
            >
                {offersView}
            </Flex>
        );
    }, [offers, containerHeight, selectedOffer]);

    return (
        <Flex
            paddingTop="size-50"
        >
            <Grid
                minHeight="490px"
                flex="1"
                columns={['2fr', '3fr']}
                rows={['size-600', '1fr', '110px', 'size-400']}
                gap="size-300"
            >
                <Text
                    gridColumn="1"
                    alignSelf="end"
                    data-testid="offersTab/result"
                >
                    Offers for {resultText}
                </Text>
                <View
                    gridColumn="span 1"
                    gridRow="span 2"
                    overflow-y="auto"
                    borderRadius="regular"
                    borderWidth="thin"
                    borderColor="light"
                    backgroundColor="gray-50"
                    height={containerHeight - 260}
                    alignSelf="stretch"
                    overflow="hidden auto"
                >
                    {offerListView}
                </View>
                <Tabs
                    aria-label="Configuration"
                    gridColumn="2 / span 1"
                    gridRow="1 / span 2"
                    defaultSelectedKey={selectedTab}
                    onSelectionChange={setCurrentPlaceholderTab}
                >
                    <Flex justifyContent="center">
                        <TabList>
                            <Item key={KEY_PRICE}>Price</Item>
                            <Item key="checkout">Checkout</Item>
                        </TabList>
                    </Flex>
                    <TabPanels>
                        <Item key={KEY_PRICE}>
                            <Flex
                                direction="column"
                                gap="size-100"
                            >
                                <View
                                    overflow-y="scroll"
                                    paddingTop="size-200"
                                    paddingLeft="size-200"
                                    paddingRight="size-200"
                                    height="100%"
                                >
                                    {!selectedOffer && (
                                        <Flex justifyContent="center">
                                            Please select an offer on the left.
                                        </Flex>
                                    )}
                                    {pricePlaceholders}
                                </View>
                            </Flex>
                        </Item>
                        <Item key="checkout">
                            <CheckoutTab
                                selectedOffer={selectedOffer}
                                checkoutPlaceholders={checkoutPlaceholders}
                                checkoutType={checkoutType}
                                workflowStep={workflowStep}
                                setCheckoutType={setCheckoutType}
                                setWorkflowStep={setWorkflowStep}
                                ctaText={ctaText}
                                setCtaText={setCtaText}
                                ctaTextOption={ctaTextOption}
                            />
                        </Item>
                    </TabPanels>
                </Tabs>
                <View gridRow="span 1" alignSelf="end">
                    {selectedOffer && (
                        <View
                            backgroundColor={expandDetails ? 'gray-200' : ''}
                            borderRadius="regular"
                            borderColor="light"
                            paddingStart="size-100"
                            paddingEnd="size-100"
                        >
                            <Flex direction="column">
                                <Flex
                                    direction="row-reverse"
                                    marginTop="size-200"
                                    justifyContent="space-between"
                                >
                                    <ToggleButton
                                        isEmphasized
                                        isSelected={expandDetails}
                                        onChange={setExpandDetails}
                                        aria-label="Options"
                                    >
                                        {expandDetails ? (
                                            <ChevronDoubleRight />
                                        ) : (
                                            <ChevronDoubleLeft />
                                        )}
                                    </ToggleButton>
                                    {expandDetails && (
                                        <PromoTag
                                            promoOverride={promoOverride}
                                            setPromoOverride={setPromoOverride}
                                            status={promoStatus}
                                        ></PromoTag>
                                    )}
                                </Flex>
                                {expandDetails &&
                                    currentPlaceholderTab === KEY_PRICE && (
                                        <CheckboxGroup
                                            label="Disable"
                                            orientation="horizontal"
                                            value={placeholderOptions}
                                            onChange={setPlaceholderOptions}
                                        >
                                            <Checkbox value="displayFormatted">
                                                HTML Format
                                            </Checkbox>
                                            <Checkbox value="displayRecurrence">
                                                Term
                                            </Checkbox>
                                            <Checkbox value="displayPerUnit">
                                                Unit
                                            </Checkbox>
                                            <Checkbox value="displayTax">
                                                Tax Label
                                            </Checkbox>
                                            <Checkbox value="forceTaxExclusive">
                                                Include Tax
                                            </Checkbox>
                                            <Checkbox value="displayOldPrice">
                                                Old price
                                            </Checkbox>
                                        </CheckboxGroup>
                                    )}
                            </Flex>
                        </View>
                    )}
                </View>
                <Flex justifyContent="space-between" gridColumn="span 2">
                    <Button
                        aria-label="previous-step"
                        variant="primary"
                        onPress={previousStep}
                    >
                        Back
                    </Button>
                    <Flex>
                        {onCancel && (
                            <Button
                                aria-label="cancel"
                                variant="primary"
                                onPress={onCancel}
                            >
                                Cancel
                            </Button>
                        )}
                        {disablePlaceholderSelection && (
                            <Button
                                marginStart="size-200"
                                aria-label="previous-step"
                                variant="cta"
                                onPress={useClickHandler}
                                isDisabled={!offerSelectorId}
                            >
                                Use
                            </Button>
                        )}
                    </Flex>
                </Flex>
            </Grid>
        </Flex>
    );
}

OffersTab.propTypes = {
    onSelect: PropTypes.func.isRequired,
    ...PrevNext,
};

export default OffersTab;

import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Item, View, Picker } from '@adobe/react-spectrum';

const CountryPicker = ({ country, globals, setGlobals }) => {
    const [countryList, setCountryList] = useState([{ id: 'US', name: 'US' }]);
    useEffect(() => {
        return fetch(
            'https://countries-stage.adobe.io/v2/countries?api_key=dexter-commerce-offers'
        )
            .then((response) => response.json())
            .then((data) => {
                const result = data.map((obj) => {
                    const id = obj['iso2-code'];
                    return { id, name: id };
                });
                if (!country) return result;
                // check if context country is in the list, if not, add it
                const countryInList = result.find((obj) => obj.id === country);
                if (!countryInList) {
                    result.push({ id: country, name: country });
                }
                return result;
            })
            .then(setCountryList)
            .catch(() => {});
    }, []);

    return (
        <View>
            <Picker
                label="Choose Country*"
                items={countryList}
                selectedKey={country}
                onSelectionChange={(value) =>
                    setGlobals([
                        {
                            ...globals[0],
                            country: value,
                        },
                    ])
                }
            >
                {(item) => <Item key={item.id}>{item.name}</Item>}
            </Picker>
        </View>
    );
};

CountryPicker.propTypes = {
    country: PropTypes.string,
    globals: PropTypes.any,
    setGlobals: PropTypes.func,
};

export default CountryPicker;

import React, { useEffect, useState, useCallback } from 'react';
import ReactDOM from 'react-dom';
import { DialogContainer, Dialog, Content } from '@adobe/react-spectrum';
import { defaultTheme, Provider } from '@adobe/react-spectrum';
import { EnvProvider } from '@pandora/react-env-provider';
import { FetchProvider } from '@pandora/react-fetch-provider';
import { AuthProvider } from '@pandora/react-auth-provider';
import OfferSelectorTool from './OfferSelectorTool';
import { createLog } from '@dexter/tacocat-core';

const log = createLog('OfferSelectorTool');

/**
 * Initiliaze the Offer Selector Tool as a dialog that can be triggered programmatically.
 * @type { import('./types').openAsDialog }
 */
function openAsDialog(rootElement, onSelect, appContext) {
    const closeDialog = () => {
        ReactDOM.unmountComponentAtNode(rootElement);
    };
    if (!appContext.onCancel) {
        appContext.onCancel = () => {
            log.debug('Clicked on cancel');
            if (closeDialog) closeDialog();
        };
    }
    function OfferSelectorToolDialog() {
        useEffect(() => {
            const spectrumRoot = rootElement.firstElementChild;
            const styles = document.createElement('style');
            document.head.appendChild(styles);
            const [spectrumClassName] = spectrumRoot.className.split(' ', 1);
            if (spectrumClassName) {
                styles.textContent = `.${
                    spectrumRoot.className.split(' ', 1)[0]
                } {position: relative;z-index: ${appContext.zIndex};}`;
            }
            return () => {
                document.head.removeChild(styles);
            };
        }, []);

        const authProvider = {
            getAccessToken: () => {
                return appContext.accessToken;
            },
        };

        const [contentEl, setContentEl] = useState(null);

        const setContentRef = useCallback((ref) => {
            if (ref) {
                setContentEl(ref.UNSAFE_getDOMNode());
            }
        }, []);

        return (
            <Provider theme={defaultTheme} colorScheme="light" scale="medium" width="100%" height="100%">
                <EnvProvider value={appContext.environment}>
                    <AuthProvider value={authProvider}>
                        <FetchProvider>
                            <DialogContainer
                                onDismiss={closeDialog}
                                type="modal"
                            >
                                <Dialog minWidth="1100px" minHeight="640px" height="80vh" width="80vh" ref={setContentRef}>
                                    <Content>
                                        {contentEl && (
                                            <OfferSelectorTool
                                                appContext={appContext}
                                                rootElement={contentEl}
                                                onSelect={onSelect}
                                                onCancel={closeDialog}
                                                containerGap={20}
                                            />
                                        )}
                                    </Content>
                                </Dialog>
                            </DialogContainer>
                        </FetchProvider>
                    </AuthProvider>
                </EnvProvider>
            </Provider>
        );
    }
    ReactDOM.render(<OfferSelectorToolDialog />, rootElement);
    return closeDialog;
}

export { openAsDialog };

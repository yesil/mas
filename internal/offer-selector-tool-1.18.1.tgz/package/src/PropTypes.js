import PropTypes from 'prop-types';

const OfferProp = PropTypes.shape({
    name: PropTypes.string,
    icon: PropTypes.string,
    offerId: PropTypes.string,
    pricePoint: PropTypes.string,
    planType: PropTypes.string,
});

const PrevNext = {
    previousStep: PropTypes.func,
    nextStep: PropTypes.func,
};

export { OfferProp, PrevNext };

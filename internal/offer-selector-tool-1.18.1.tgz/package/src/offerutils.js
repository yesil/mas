import { Landscape } from '@pandora/data-source-utils';
/**
 * Offer ID detection pattern
 */
const OFFER_ID_PATTERN = /^[0-9A-F]{32}$/;
const OFFER_SELECTOR_ID_PATTERN = /^[a-zA-Z0-9_-]{43}$/;
/**
 * offer filter used in for offers in listbox.
 */
const offerFilter = (
    criteria,
    landscape,
    aos,
    { customerSegments, marketSegments, arrangement_code, name, draft }
) => {
    return (
        // filter out products that don't match the customer segment
        customerSegments[aos.customerSegment] === true &&
        // filter out products that don't match the market segment
        marketSegments[aos.marketSegment] === true &&
        // only show draft offers when OST is in landscape=DRAFT
        (landscape === Landscape.DRAFT || !draft) &&
        // fake full text search in the products
        (arrangement_code === aos.arrangementCode ||
            !criteria ||
            criteria.test(name) ||
            criteria.test(arrangement_code))
    );
};

export { offerFilter, OFFER_ID_PATTERN, OFFER_SELECTOR_ID_PATTERN };

import React, { useCallback, useContext, useState } from 'react';
import PropTypes from 'prop-types';

import { Button, Heading, Link } from '@adobe/react-spectrum';

import { usePlaceholder } from '@dexter/tacocat-react-placeholders';
import AppContext from './AppContext';

const PlaceholderKey = ({
    offerSelectorId,
    type,
    name,
    description,
    doc,
    onSelect,
    options,
    workflowStep,
    clientId,
    promotionCode,
    displayOldPrice,
    marketSegment,
    checkoutType,
    isPerpetual,
    ctaText,
}) => {
    const { defaultPlaceholderOptions, disablePlaceholderSelection } =
        useContext(AppContext);
    const isCheckoutUrl = type === 'checkoutUrl';
    const placeholderOptions = Object.fromEntries(
        Object.entries(defaultPlaceholderOptions).map(([key]) => [
            key,
            !options.includes(key),
        ])
    );

    //https://jira.corp.adobe.com/browse/MWPW-134663 need to invert logic for checkbock "Disable - Include Tax"
    //corresponds to forceTaxExclusive price
    placeholderOptions.forceTaxExclusive =
        !placeholderOptions.forceTaxExclusive;

    const defaultButtonText = 'Use';
    const [buttonText, setButtonText] = useState(defaultButtonText);
    placeholderOptions.workflowStep = workflowStep;
    placeholderOptions.clientId = clientId;
    placeholderOptions.marketSegment = marketSegment;
    placeholderOptions.workflow = checkoutType;
    placeholderOptions.isPerpetual = isPerpetual;
    placeholderOptions.ctaText = ctaText;

    const onButtonClickEffect = (click) => {
        click.target.style.backgroundColor = '#696';
        setButtonText('Copied');

        setTimeout(() => {
            setButtonText(defaultButtonText);
            click.target.style.backgroundColor = null;
        }, 400);
    };

    const onCtaClick = useCallback(
        (event) => {
            onSelect(offerSelectorId, type, placeholderOptions);
            onButtonClickEffect(event);
        },
        [offerSelectorId, type, placeholderOptions]
    );

    const placeholderRef = usePlaceholder(placeholderOptions);
    return (
        <>
            <Heading level="4" margin="0">
                {name}
            </Heading>

            <Button
                isDisabled={disablePlaceholderSelection}
                gridRow="span 3"
                alignSelf="center"
                onPress={onCtaClick}
                variant="secondary"
            >
                {buttonText}
            </Button>
            <Link variant="secondary">
                <a href={doc} target="_blank" rel="noreferrer">
                    {description}
                </a>
            </Link>
            {!isCheckoutUrl && (
                <div
                    ref={placeholderRef}
                    data-offer-selector-id={offerSelectorId}
                    data-type={type}
                    data-promotion-code={promotionCode}
                    data-display-old-price={displayOldPrice}
                ></div>
            )}
            {isCheckoutUrl && (
                <a
                    ref={placeholderRef}
                    data-offer-selector-id={offerSelectorId}
                    data-promotion-code={promotionCode}
                    data-type={type}
                    target="_blank"
                >
                    Checkout Link
                </a>
            )}
            <div style={{ gridColumn: 'span 2' }}>&nbsp;</div>
        </>
    );
};

PlaceholderKey.propTypes = {
    offerSelectorId: PropTypes.string.isRequired,
    type: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    doc: PropTypes.string,
    onSelect: PropTypes.func.isRequired,
    options: PropTypes.arrayOf(PropTypes.string),
    workflowStep: PropTypes.string,
    clientId: PropTypes.string,
    promotionCode: PropTypes.string,
    displayOldPrice: PropTypes.bool,
    marketSegment: PropTypes.string,
    checkoutType: PropTypes.string,
    isPerpetual: PropTypes.bool,
    ctaText: PropTypes.string,
};

PlaceholderKey.defaultProps = {
    doc: '',
};

export default PlaceholderKey;

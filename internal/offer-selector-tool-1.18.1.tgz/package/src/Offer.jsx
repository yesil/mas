import PropTypes from 'prop-types';

import {
    Divider,
    Grid,
    Heading,
    Image,
    repeat,
    Text,
    View,
} from '@adobe/react-spectrum';
import React from 'react';
import { OfferProp } from './PropTypes';
import { useLayoutEffect } from 'react';
import { useRef } from 'react';
import { Price } from '@pandora/react-price';

function Offer({
    offer: {
        offer_id,
        name,
        icon,
        pricing: {
            currency: { symbol, format_string: formatString } = {},
            prices: [
                { price_details: { display_rules: { price } = {} } = {} } = {},
            ] = [],
        } = {},
        planType,
        offer_type: offerType,
        language,
        price_point: pricePoint,
    } = {},
    selected = false,
}) {
    const viewRef = useRef();
    useLayoutEffect(() => {
        if (selected && viewRef.current) {
            viewRef.current.UNSAFE_getDOMNode().scrollIntoView();
        }
    }, [viewRef.current]);

    return (
        <View
            ref={viewRef}
            borderRadius="regular"
            width="100%"
            borderWidth="thin"
            borderColor="light"
            padding="static-size-100"
            backgroundColor={selected ? 'gray-200' : 'gray-50'}
        >
            <Grid
                columns={repeat(10, 'auto')}
                rows={[
                    'auto',
                    '20px',
                    'static-size-500',
                    'static-size-500',
                    'auto',
                ]}
            >
                <Image width="48px" src={icon} alt="" gridColumn="1/span 1" />
                <Heading
                    level="4"
                    gridColumn="2/span 9"
                    alignSelf="center"
                    margin="0"
                    data-testid={pricePoint}
                >
                    {name}
                </Heading>
                <Divider size="S" gridColumn="1/span 10" alignSelf="center" />
                <Heading level="5" gridColumn="span 2" margin="0">
                    Offer ID
                </Heading>
                <Text gridColumn="span 8">{offer_id}</Text>
                <Heading level="5" gridColumn="span 2" margin="0">
                    Price Point
                </Heading>
                <Text gridColumn="span 8">{pricePoint}</Text>
                <Heading level="5" gridColumn="span 2" margin="0">
                    Plan Type
                </Heading>
                <Heading level="5" gridColumn="span 2" margin="0">
                    Offer type
                </Heading>
                <Heading level="5" gridColumn="span 2" margin="0">
                    Language
                </Heading>
                <Heading level="5" gridColumn="span 4" margin="0">
                    Price
                </Heading>
                <Text gridColumn="span 2">{planType}</Text>
                <Text gridColumn="span 2">{offerType}</Text>
                <Text gridColumn="span 2">{language}</Text>
                <Text gridColumn="span 4">
                    {formatString && <Price data={{ formatString, price }} />}
                </Text>
            </Grid>
        </View>
    );
}

Offer.propTypes = { offer: OfferProp, selected: PropTypes.bool };

Offer.defaultProps = { offer: {} };

export default Offer;

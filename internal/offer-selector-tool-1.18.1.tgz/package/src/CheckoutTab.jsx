import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
    Flex,
    Item,
    View,
    Picker,
    RadioGroup,
    Radio,
} from '@adobe/react-spectrum';
import { CheckoutType } from '@pandora/commerce-checkout-url-builder';
import { getDefaultWorkflowStep, listWorkflowStepsForType } from './checkout';

const CheckoutTab = ({
    selectedOffer,
    checkoutPlaceholders,
    checkoutType,
    workflowStep,
    setCheckoutType,
    setWorkflowStep,
    ctaText,
    setCtaText,
    ctaTextOption,
}) => {
    const [workflowStepOptions, setWorkflowStepOptions] = useState(
        listWorkflowStepsForType(checkoutType)
    );
    return (
        <View
            backgroundColor="gray-200"
            padding="static-size-200"
            borderRadius="regular"
            borderWidth="thin"
            borderColor="light"
        >
            <Flex
                direction="column"
                width="100%"
                height="100%"
                justifyContent="space-evenly"
                gap="static-size-200"
            >
                {checkoutPlaceholders}

                <RadioGroup
                    label="Choose your checkout type"
                    orientation="horizontal"
                    isRequired
                    necessityIndicator="icon"
                    value={checkoutType}
                    onChange={(checkoutType) => {
                        setCheckoutType(checkoutType);
                        setWorkflowStepOptions(
                            listWorkflowStepsForType(checkoutType)
                        );
                        setWorkflowStep(getDefaultWorkflowStep(checkoutType));
                    }}
                >
                    <Radio value={CheckoutType.V3}>{CheckoutType.V3}</Radio>
                    <Radio value={CheckoutType.V2}>{CheckoutType.V2}</Radio>
                </RadioGroup>
                <Picker
                    label="Choose your Workflow Step"
                    items={workflowStepOptions}
                    selectedKey={workflowStep}
                    isRequired
                    necessityIndicator="icon"
                    onSelectionChange={(option) => setWorkflowStep(option)}
                >
                    {(item) => <Item>{item.name}</Item>}
                </Picker>
                {ctaTextOption && ctaTextOption?.getTexts().length > 0 ? (
                    <Picker
                        label="Choose your Cta text"
                        items={ctaTextOption.getTexts()}
                        selectedKey={ctaText}
                        isRequired
                        necessityIndicator="icon"
                        onSelectionChange={(option) => setCtaText(option)}
                    >
                        {(item) => <Item>{item.name}</Item>}
                    </Picker>
                ) : null}
                {!selectedOffer ? 'Please select an offer on the left.' : ''}
            </Flex>
        </View>
    );
};

CheckoutTab.propTypes = {
    selectedOffer: PropTypes.object,
    checkoutPlaceholders: PropTypes.any,
    checkoutType: PropTypes.string,
    workflowStep: PropTypes.string,
    setCheckoutType: PropTypes.func,
    setWorkflowStep: PropTypes.func,
    ctaText: PropTypes.string,
    setCtaText: PropTypes.func,
    ctaTextOption: PropTypes.object,
};

export default CheckoutTab;

/**
 * @typedef { import('./types').AosParams } AosParams
 * @param {URLSearchParams} searchParameters
 * @param {AosParams} defaultAosParams Default Aos values
 * @return {AosParams}
 */
const getSelectedAosParams = (searchParameters, defaultAosParams) => {
    Object.entries(defaultAosParams).forEach(([key, value]) => {
        if (searchParameters.has(key)) {
            defaultAosParams[key] = value;
        }
    });
    return defaultAosParams;
};

const getSelectedCountry = (searchParameters, globals) => {
    const country = searchParameters.get('country');
    if (country) {
        return [{ ...globals[0], country }];
    }

    return globals;
};

export { getSelectedAosParams, getSelectedCountry };

import {
    Button,
    Divider,
    Flex,
    Grid,
    Heading,
    Image,
    Item,
    ListBox,
    Picker,
    Radio,
    RadioGroup,
    Text,
    TextField,
    View,
} from '@adobe/react-spectrum';
import React, { useContext, useEffect, useMemo } from 'react';

import {
    OfferType,
    CustomerSegment,
    MarketSegment,
    Commitment,
    Term,
} from '@pandora/data-models-odm';
import Magnify from '@spectrum-icons/workflow/Magnify';

import AppContext from './AppContext';
import {
    offerFilter,
    OFFER_ID_PATTERN,
    OFFER_SELECTOR_ID_PATTERN,
} from './offerutils';
import { PrevNext } from './PropTypes';
import { AosClient } from '@pandora/data-source-aos';
import { useOfferGet } from '@pandora/data-source-offers';
import { useOfferSelectorGet } from '@pandora/data-source-offers';
import { createLog } from '@dexter/tacocat-core';
import { Environment } from '@pandora/data-source-utils';
import { useCallback } from 'react';
import CountryPicker from './CountryPicker';

const environment = Environment.PRODUCTION;
const log = createLog('OfferSelectorTool');

function ProductsTab({ nextStep }) {
    const {
        allProducts,
        filteredProducts,
        setFilteredProducts,
        searchText,
        setSearchText,
        searchOfferId,
        setSearchOfferId,
        searchOfferSelectorId,
        setSearchOfferSelectorId,
        sendSearch,
        setSendSearch,
        selectedProduct,
        setAosParams,
        globals,
        setGlobals,
        apiKey,
        landscape,
        env,
        baseUrl,
        aosParams,
        disableOfferSelection,
        containerHeight,
        onCancel,
        accessToken,
    } = useContext(AppContext);

    const getAosClient = (fetchOptions) =>
        new AosClient({
            ...fetchOptions,
            accessToken,
            env,
            baseUrl,
            landscape,
            apiKey,
        });

    const getOfferSelector = useOfferSelectorGet(getAosClient);
    const getOffer = useOfferGet(getAosClient);
    const country = globals[0]?.country;

    // can be passed offerIds or offerSelectorId
    const upsertOffer = (promise) =>
        promise
            .then((offer) => {
                setAosParams(offer);
            })
            .catch((error) => {
                if (error.status !== 404) throw error;
            });

    useEffect(() => {
        if (
            !searchOfferId &&
            !searchOfferSelectorId &&
            aosParams.pricePoint !== ''
        ) {
            // clear price point from the aos parameters as it cannot be set via the ui.
            setAosParams({
                ...aosParams,
                pricePoint: '',
            });
        }
    }, [searchOfferId, searchOfferSelectorId]);

    // search by offer selector id
    useEffect(() => {
        if (!searchOfferSelectorId) return;
        return upsertOffer(
            getOfferSelector(
                { id: searchOfferSelectorId, country },
                { apiKey, environment, landscape }
            ).then(
                ({
                    data: {
                        commitment,
                        customer_segment: customerSegment,
                        market_segment: marketSegment,
                        offer_type: offerType,
                        price_point: pricePoint,
                        product_arrangement_code: arrangementCode,
                        term,
                    } = {},
                }) => ({
                    arrangementCode,
                    commitment,
                    customerSegment,
                    marketSegment,
                    offerSelectorId: searchOfferSelectorId,
                    offerType,
                    pricePoint,
                    term,
                })
            )
        ).catch((error) => {
            log.error(
                `Failed to search by offer selector id "${searchOfferSelectorId}":`,
                error
            );
        });
    }, [searchOfferSelectorId, setAosParams]);

    // search by offer id
    useEffect(() => {
        if (!searchOfferId) return;
        return upsertOffer(
            getOffer(
                { offerIds: [searchOfferId], country },
                { apiKey, environment, landscape }
            ).then(
                ({
                    data: [
                        {
                            commitment,
                            customer_segment: customerSegment,
                            market_segments: [marketSegment] = [],
                            offer_type: offerType,
                            price_point: pricePoint,
                            product_arrangement_code: arrangementCode,
                            term,
                        } = {},
                    ] = [],
                }) => ({
                    arrangementCode,
                    commitment,
                    customerSegment,
                    marketSegment,
                    offerId: searchOfferId,
                    offerType,
                    pricePoint,
                    term,
                })
            )
        ).catch((error) => {
            log.error(
                `Failed to search by offer id "${searchOfferId}":`,
                error
            );
        });
    }, [searchOfferId, setAosParams]);

    useEffect(() => {
        if (disableOfferSelection) {
            return;
        }
        // extract offer id from the search text
        if (OFFER_ID_PATTERN.test(searchText)) {
            setSearchOfferId(searchText);
        } else if (OFFER_SELECTOR_ID_PATTERN.test(searchText)) {
            setSearchOfferSelectorId(searchText);
        } else if (searchOfferId) {
            // if previous is a wrong offer id is set, clear it
            setSearchOfferId();
        } else if (searchOfferSelectorId !== '') {
            setSearchOfferSelectorId('');
        }
    }, [searchText]);

    useEffect(() => {
        let criteria;
        try {
            criteria = new RegExp(searchText, 'i');
        } catch {
            // ignore
        }

        const filteredProducts = allProducts
            ? allProducts
                  .filter(([, product]) =>
                      offerFilter(criteria, landscape, aosParams, product)
                  )
                  .map(([code, p]) => ({
                      id: code,
                      code,
                      ...p,
                  }))
            : [];
        setFilteredProducts(filteredProducts);
    }, [allProducts, searchText, aosParams]);

    const defaultPlanType = useMemo(() => {
        const planType = [];
        if (aosParams.commitment) planType.push(aosParams.commitment);
        if (aosParams.term) planType.push(aosParams.term);
        return planType.join('-');
    }, [aosParams]);

    const searchKeyPressHandler = useCallback(
        (event) => {
            if (selectedProduct && event.key === 'Enter') {
                nextStep(true);
            }
        },
        [selectedProduct, nextStep]
    );

    useEffect(() => {
        if (sendSearch && selectedProduct) {
            // trigger search for the initial dialog open but then stop sending search.
            setSendSearch(false);
            nextStep(true);
        }
    }, [selectedProduct, sendSearch]);

    const productList = useMemo(
        () => (
            <View
                backgroundColor="gray-50"
                gridArea="products"
                borderRadius="regular"
                borderWidth="thin"
                borderColor="light"
            >
                <Flex direction="column" alignItems="center">
                    <TextField
                        description="Search by name, product code, offer id or offer selector id"
                        label="Search"
                        icon={<Magnify />}
                        onChange={setSearchText}
                        data-testid="productsTab/search"
                        width="size-6000"
                        autoFocus
                        onKeyDown={searchKeyPressHandler}
                        value={searchText}
                    />
                    <Divider
                        size="S"
                        marginTop="size-200"
                        marginBottom="size-200"
                    />
                    <ListBox
                        aria-label="Products"
                        alignSelf="stretch"
                        justifySelf="stretch"
                        items={filteredProducts}
                        selectionMode="single"
                        selectedKeys={[aosParams.arrangementCode]}
                        height={containerHeight - 380}
                        onSelectionChange={(selected) => {
                            if (
                                !searchOfferId ||
                                searchOfferSelectorId === ''
                            ) {
                                setAosParams({
                                    ...aosParams,
                                    arrangementCode: selected.anchorKey,
                                });
                            }
                        }}
                    >
                        {({ code, name, icon, draft }) => (
                            <Item textValue={code} aria-label={name}>
                                <Image
                                    width="48px"
                                    height="48px"
                                    src={icon}
                                    alt="Product Icon"
                                    slot="icon"
                                />
                                <Text
                                    gridArea="end"
                                    UNSAFE_className={draft ? 'draft' : ''}
                                >
                                    {' '}
                                    {draft && 'DRAFT'}
                                </Text>
                                <Text
                                    data-testid={code}
                                    alignSelf="center"
                                    UNSAFE_className="productName"
                                >
                                    {name}
                                </Text>
                                <Text
                                    slot="description"
                                    // alignSelf="center"
                                    UNSAFE_className="productName"
                                >
                                    {code}
                                </Text>
                            </Item>
                        )}
                    </ListBox>
                </Flex>
            </View>
        ),
        [filteredProducts, containerHeight, selectedProduct]
    );

    // tab 1 / filters
    const filters = (
        <View
            backgroundColor="gray-50"
            gridArea="entitlements"
            borderRadius="regular"
            borderWidth="thin"
            borderColor="light"
            paddingStart="size-200"
            paddingEnd="size-200"
        >
            <Flex direction="column" width="100%">
                <Heading level="3">Select your entitlements</Heading>
                <Divider
                    size="S"
                    marginTop="size-100"
                    marginBottom="size-200"
                />
                <Flex
                    direction="column"
                    width="100%"
                    justifyContent="space-evenly"
                >
                    <Picker
                        label="Choose your plan type*"
                        selectedKey={defaultPlanType}
                        width="size-4600"
                        onSelectionChange={(value) => {
                            const [commitment, term] = value.split('-');
                            setAosParams({
                                ...aosParams,
                                commitment,
                                term,
                            });
                        }}
                    >
                        <Item key={''}>ALL</Item>
                        <Item key={`${Commitment.YEAR}-${Term.MONTHLY}`}>
                            ABM
                        </Item>
                        <Item key={`${Commitment.YEAR}-${Term.ANNUAL}`}>
                            PUF
                        </Item>
                        <Item key={`${Commitment.MONTH}-${Term.MONTHLY}`}>
                            M2M
                        </Item>
                        <Item key={`${Commitment.TERM_LICENSE}-${Term.P3Y}`}>
                            P3Y
                        </Item>
                        <Item key={`${Commitment.PERPETUAL}`}>PERPETUAL</Item>
                    </Picker>
                    <RadioGroup
                        label="Choose your customer segment*"
                        orientation="horizontal"
                        value={aosParams.customerSegment}
                        onChange={(value) =>
                            setAosParams({
                                ...aosParams,
                                customerSegment: value,
                            })
                        }
                    >
                        <Radio value="INDIVIDUAL">
                            {CustomerSegment.INDIVIDUAL}
                        </Radio>
                        <Radio value="TEAM">{CustomerSegment.TEAM}</Radio>
                    </RadioGroup>
                    <Picker
                        label="Choose your offer type*"
                        selectedKey={aosParams.offerType}
                        width="size-4600"
                        onSelectionChange={(key) =>
                            setAosParams({
                                ...aosParams,
                                offerType: key,
                            })
                        }
                    >
                        <Item key={OfferType.BASE}>{OfferType.BASE}</Item>
                        <Item key={OfferType.TRIAL}>{OfferType.TRIAL}</Item>
                        <Item key={OfferType.PROMOTION}>
                            {OfferType.PROMOTION}
                        </Item>
                    </Picker>
                    <RadioGroup
                        label="Choose your market segment*"
                        orientation="horizontal"
                        value={aosParams.marketSegment}
                        onChange={(value) =>
                            setAosParams({
                                ...aosParams,
                                marketSegment: value,
                            })
                        }
                    >
                        <Radio value="COM">{MarketSegment.COM}</Radio>
                        <Radio value="EDU">{MarketSegment.EDU}</Radio>
                        <Radio value="GOV">{MarketSegment.GOV}</Radio>
                    </RadioGroup>
                    <CountryPicker
                        country={country}
                        globals={globals}
                        setGlobals={setGlobals}
                    />
                    <View
                    paddingTop="size-200">
                        <Text>
                            {aosParams.commitment === 'PERPETUAL' || country === 'GB' ? 'Language (MULT/EN): EN' : ''}
                        </Text>
                    </View>
                </Flex>
            </Flex>
        </View>
    );

    return (
        <View height="100%">
            <Grid
                height="100%"
                minHeight="400px"
                areas={[
                    'header  header',
                    'products entitlements',
                    'footer  footer',
                ]}
                columns={['1fr', '1fr']}
                rows={['size-600', 'auto', 'size-400']}
                gap="size-200"
            >
                <Heading level="3" gridArea="header">
                    Select your product from the list below
                </Heading>
                {productList}
                {filters}
                <View justifySelf="end" gridArea="footer">
                    {onCancel && (
                        <Button
                            data-testid="productsTab/cancelButton"
                            marginEnd="size-200"
                            aria-label="cancel"
                            variant="primary"
                            onPress={onCancel}
                        >
                            Cancel
                        </Button>
                    )}
                    <Button
                        data-testid="productsTab/nextButton"
                        aria-label="next-step"
                        variant="cta"
                        isDisabled={!selectedProduct}
                        onPress={() => {
                            nextStep(true);
                        }}
                    >
                        Next
                    </Button>
                </View>
            </Grid>
        </View>
    );
}

ProductsTab.propTypes = {
    ...PrevNext,
};

export default ProductsTab;

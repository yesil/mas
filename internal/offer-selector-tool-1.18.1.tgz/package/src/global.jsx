import React from 'react';
import ReactDOM from 'react-dom';
import { defaultTheme, Provider } from '@adobe/react-spectrum';
import { EnvProvider } from '@pandora/react-env-provider';
import { FetchProvider } from '@pandora/react-fetch-provider';
import { AuthProvider } from '@pandora/react-auth-provider';
import OfferSelectorTool from './OfferSelectorTool';
import styles from './app.less';

import {
    createWcsClient,
    createWcsPlaceholderProvider,
    wcsRejectedHtmlPlaceholderTemplate,
    wcsPriceHtmlPlaceholderTemplate,
    wcsPriceOpticalHtmlPlaceholderTemplate,
    wcsPriceStrikethroughHtmlPlaceholderTemplate,
    wcsPriceAnnualHtmlPlaceholderTemplate,
    wcsCheckoutHrefPlaceholderTemplate,
} from '@dexter/tacocat-wcs-client';
import { createPlaceholderEngine } from '@dexter/tacocat-core';

import {
    Environment,
    Landscape,
    ProviderEnvironment,
} from '@pandora/data-source-utils';

function openOfferSelectorTool({
    country,
    language,
    env = ProviderEnvironment.PRODUCTION,
    environment = Environment.PRODUCTION,
    landscape = Landscape.PUBLISHED,
    wcsApiKey,
    aosApiKey,
    aosAccessToken,
    promotionCode,
    checkoutClientId,
    onSelect,
    searchParameters,
    searchOfferSelectorId,
    defaultPlaceholderOptions,
    ctaTextOption,
    rootElement = document.getElementsByClassName('ost')[0],
}) {
    let wcsBaseUrl = 'https://wcs.adobe.io';
    // search parameters
    let searchOfferId = searchParameters.get('offerId');

    // promotion Code
    const paramPromotionCode = searchParameters.get('promotionCode');
    const paramPromotionOverride = searchParameters.get('storedPromoOverride');

    if (env.toUpperCase() === 'STAGE') {
        wcsBaseUrl = 'https://wcs-stage.adobe.io';
    }

    if (styles) {
        // hack to get app.less file bundled by swc.
    }

    const engine = (wcsApiKey, wcsBaseUrl) =>
        createPlaceholderEngine().register(
            createWcsPlaceholderProvider(
                createWcsClient({
                    apiKey: wcsApiKey,
                    env,
                    environment,
                    landscape,
                    baseUrl: wcsBaseUrl,
                }),
                {
                    checkoutWorkflow: 'UCv3',
                }
            ),
            wcsRejectedHtmlPlaceholderTemplate,
            wcsPriceHtmlPlaceholderTemplate,
            wcsPriceOpticalHtmlPlaceholderTemplate,
            wcsPriceStrikethroughHtmlPlaceholderTemplate,
            wcsPriceAnnualHtmlPlaceholderTemplate,
            wcsCheckoutHrefPlaceholderTemplate
        );

    /**
      @type { import('../src/types').ContextParams }
     */
    const appContext = {
        aosParams: {
            marketSegment: 'COM',
            offerType: 'BASE',
        },
        apiKey: aosApiKey,
        accessToken: aosAccessToken || localStorage.getItem('AOS_ACCESS_TOKEN'),
        env,
        environment,
        landscape,
        engine: engine(wcsApiKey, wcsBaseUrl),
        globals: [
            {
                checkoutWorkflow: 'UCv3',
                country,
                language,
            },
        ],
        defaultPlaceholderOptions: {
            displayFormatted: true,
            displayRecurrence: true,
            displayPerUnit: true,
            displayTax: false,
            forceTaxExclusive: false,
        },
        offerSelectorPlaceholderOptions: {
            displayFormatted: true,
        },
        promotionCode: paramPromotionCode || promotionCode,
        storedPromoOverride: paramPromotionOverride,
        disableOfferSelection: false,
        disablePlaceholderSelection: false,
        searchOfferId,
        searchOfferSelectorId,
        defaultPlaceholderOptions,
        checkoutClientId,
        searchParameters,
        containerHeight: rootElement.offsetHeight,
        ctaTextOption,
    };

    const authProvider = {
        getAccessToken: () => {
            return appContext.accessToken;
        },
    };

    const App = () => {
        return (
            <Provider theme={defaultTheme} colorScheme="light" scale="medium" width="100%" height="100%">
                <EnvProvider value={appContext.environment}>
                    <AuthProvider value={authProvider}>
                        <FetchProvider>
                            <OfferSelectorTool
                                appContext={appContext}
                                onSelect={onSelect}
                                rootElement={rootElement}
                            />
                        </FetchProvider>
                    </AuthProvider>
                </EnvProvider>
            </Provider>
        );
    };
    ReactDOM.render(<App />, rootElement);
}

export { openOfferSelectorTool };

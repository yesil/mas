import { createLog } from '@dexter/tacocat-core';

const log = createLog('OfferSelectorTool');

/**
 * Service for resolving the offer selector id for an offer.
 * Behind the scene, it attemps to create a new one, if an OSI exists for the same params, AOS will return an existing offer selector.
 * @param {offer} offer data
 * @param {createOfferSelector} helper function to create an offer selector
 * @param {queryOptions} AOS query parameters
 * @returns an offer selector object
 */
async function resolveOfferSelector(
    {
        product_arrangement_code,
        buying_program,
        commitment,
        term,
        customer_segment,
        market_segments: [market_segment],
        sales_channel,
        offer_type,
        price_point,
        merchant,
    },
    createOfferSelector,
    queryOptions
) {
    const offerSelectorParams = {
        product_arrangement_code,
        buying_program,
        commitment,
        term,
        customer_segment,
        market_segment,
        sales_channel,
        offer_type,
        price_point,
        merchant,
    };
    return createOfferSelector(offerSelectorParams, queryOptions).then(
        ({ data: { id } }) => {
            log.debug('Offer Selector Id resovled:', id);
            return id;
        }
    );
}

export default resolveOfferSelector;

/**
 * PROMOTION TAG
 * indicates current promotion code context, and allows to override
 * note <code>computePromoStatus</code> is not directly used in there, but contains most dependencies here,
 * hence locating in that file.
 */
import {
    ActionButton,
    Badge,
    Flex,
    Text,
    TextField,
} from '@adobe/react-spectrum';
import { PROMO_CONTEXT_CANCEL_VALUE } from '@dexter/tacocat-core';
import React from 'react';
import EditCircle from '@spectrum-icons/workflow/EditCircle';
import Cancel from '@spectrum-icons/workflow/Cancel';
import Undo from '@spectrum-icons/workflow/Undo';
import PropTypes from 'prop-types';

/**
 * @param {*} next step
 * @returns piece of UI to show & edit Promotion context
 */
function PromoTag({ promoOverride, setPromoOverride, status }) {
    return (
        <Flex
            direction="row"
            alignContent="stretch"
            gap="2%"
            alignItems="center"
            height="100%"
            width="100%"
        >
            <Text>Promotion:</Text>
            <Badge variant={status.variant} UNSAFE_className={status.className}>
                {status.isOverriden && <EditCircle> </EditCircle>}
                <Text>{status.text}</Text>
            </Badge>
            <ActionButton
                isQuiet="true"
                UNSAFE_className="promo-tag-button"
                onPress={() => {
                    setPromoOverride(PROMO_CONTEXT_CANCEL_VALUE);
                }}
            >
                <Cancel size="S" />
            </ActionButton>
            <TextField
                label="Override"
                labelPosition="side"
                value={promoOverride || ''}
                onChange={setPromoOverride}
            />
            <ActionButton
                isQuiet="true"
                UNSAFE_className="promo-tag-button"
                onPress={() => {
                    setPromoOverride(''); //hack to empty textfield
                    setPromoOverride(undefined);
                }}
            >
                <Undo size="S" />
            </ActionButton>
        </Flex>
    );
}

PromoTag.propTypes = {
    promoOverride: PropTypes.string,
    setPromoOverride: PropTypes.func.isRequired,
    status: PropTypes.object.isRequired,
};

export { PromoTag };
